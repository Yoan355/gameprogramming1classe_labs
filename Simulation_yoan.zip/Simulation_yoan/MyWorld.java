import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MyWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MyWorld extends World
{
 
    private long lastFrameTimeMS;
    private double timeStepDuration;
    
    
    public void prepare(){

        CannonBall cannonBall = new CannonBall();
        addObject(cannonBall,261,141);
        CannonBall cannonBall2 = new CannonBall();
        addObject(cannonBall2,456,124);
    }
    
    
    /**
     * Constructor for objects of class MyWorld.
     * 
     */
    public MyWorld()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(1024, 768, 1); 
        prepare();
        
        lastFrameTimeMS = System.currentTimeMillis();
        timeStepDuration = 1.0/60;
        
        
    }
    
    
    public void act(){
    
    timeStepDuration = (System.currentTimeMillis() - lastFrameTimeMS) / 1000.0;
    lastFrameTimeMS = System.currentTimeMillis();
    
    }
    
    
    
    public double getTimeStepDuration(){
    
    return timeStepDuration;
    
    }
}
